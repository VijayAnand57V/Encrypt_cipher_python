import socket 
import Atbash_cipher as ac
import Decrypt_Caesar_cipher as dcc
import Vigenere_cipher as vc
import Baconian_cipher as bc
import Encrypt_Caesar_cipher as ecc
import onetimepad
# take the server name and port name 

host = 'local host'
port = 5050

# create a socket at client side 
# using TCP / IP protocol 
s = socket.socket(socket.AF_INET, 
				socket.SOCK_STREAM) 

# connect it to server and port 
# number on local computer. 
s.connect(('127.0.0.1', port)) 

# receive message string from 
# server, at a time 1024 B 
msg = s.recv(1024) 
host = 'local host'
port2 = 5080
   
# create a socket at server side 
# using TCP / IP protocol 
s = socket.socket(socket.AF_INET,  
                  socket.SOCK_STREAM) 
   
# bind the socket with server 
# and port number 
s.bind(('', port2)) 
   
# allow maximum 1 connection to 
# the socket 
s.listen(1) 
   
# wait till a client accept 
# connection 
c, addr = s.accept() 
   
# wait till a client accept 
# connection 

# msge = "Bye.............."
# c.send(msge.encode()) 

print('Recived:' + msg.decode()) 
	

val = msg.decode("utf-8")

# repeat as long as message 
# string are not empty 

valm = input("Enter D to decrypt or E to encrypt or N to exit: ") 
if valm=="D":
    
    vali = input("Enter the Type, \n1.Atbash\n2.Caesar\n3.Vigenere cipher\n4.Baconian cipher\n5.One Time Pad\n")
    if vali == "1":
        ob = ac.Solution()
        ReVal = ob.solve(val)
        print('Recived:' + ReVal) 
    if vali == "2":
        shif = input("Enter the shift:-")
        dcc.decrypt(str(val),int(shif))

    if vali == "3":
        key = input("Enter the key:-")
        
        Rval = vc.originalText(val,key)
        print(Rval)
    if vali == "4":

        print(bc.decrypt(val.lower()))
    if vali == "5":
        key = input("Enter the key:-")
        msg = onetimepad.decrypt(val, key)
        print(msg)
if val == "N":
    print("Gone")




# display client address 
print("CONNECTION FROM:", str(addr)) 
   
# send message to the client after  
# encoding into binary string 
num = input("""\n1.Send without encrypting\n2.Send with Atbash_cipher\n3.Send with Caesar cipher\n4.Send with Vigenere cipher\n5.Send with Baconian cipher\n6.Send with One time pad\n""") 

if (num == "1"):
    val = input("Enter the message:")

    # ob = ac.Solution()
    # ReVal = ob.solve(val)
    res = bytes(val, 'utf-8') 
    c.send(res) 
if (num == "2"):
    val = input("Enter the message:")

    ob = ac.Solution()
    ReVal = ob.solve(val)
    res = bytes(ReVal, 'utf-8') 
    c.send(res) 
if (num == "3"):
    shift = input("Enter the shift:")
    val = input("Enter the message:")
    ReVal = ecc.encrypt(str(val),int(shift))
    print(ReVal)
    res = bytes(ReVal, 'utf-8') 
    c.send(res) 
if ( num == "4"):
    keyword = input("Enter the key")
    para = input("Enter the message")
    key = vc.generateKey(para,keyword)
    print("The key is :",key)
    RVal = vc.cipherText(para,key)
    res = bytes(RVal, 'utf-8') 
    c.send(res) 
if ( num == "5"):
    val = input("Enter the message:")
    RVal = bc.encrypt(val.upper())
    res = bytes(RVal, 'utf-8') 
    c.send(res) 
if ( num == "6"):
    val = input("Enter the message:")
    key = input("Enter the key")
    cipher = onetimepad.encrypt(val,key)
    print(cipher)
    res = bytes(cipher, 'utf-8') 
    c.send(res) 
# msg = "Bye.............."
# c.send(msg.encode()) 

# disconnect the server
