class Solution:
   def solve(self, text):
      N = ord('z') + ord('a')
      print(N)
      ans=''
      return ans.join([chr(N - ord(s)) for s in text])

